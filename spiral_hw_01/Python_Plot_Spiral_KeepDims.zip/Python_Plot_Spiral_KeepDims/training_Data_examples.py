import MNIST_Loader_MichaelNielsen_RawData
#training_data, validation_data, test_data = MNIST_Loader_MichaelNielsen.load_data_wrapper()
tr_d, va_d, te_d = MNIST_Loader_MichaelNielsen_RawData.load_data_wrapper()
#import Network_code_Michael_Nielsen
#net = Network_code_Michael_Nielsen.Network([784, 30, 10])
#net.SGD(training_data, 30, 10, 3.0, test_data=test_data)
print("len(training_data)")
print(len(training_data))
print("training_data[0]")
print(training_data[0])
print("training_data[0][0]")
print(training_data[0][0])
print("training_data[0][1]")
print(training_data[0][1])