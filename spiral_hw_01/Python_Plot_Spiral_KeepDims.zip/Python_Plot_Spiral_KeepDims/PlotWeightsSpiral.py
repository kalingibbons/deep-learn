# -*- coding: utf-8 -*-
"""
Created on Fri Sep 15 16:10:58 2017

@author: johnchiasson
"""
import numpy as np
import matplotlib.pyplot as plt
print("len(W2t):"), len(W2)
print
print("W2t.shape:"), W2.shape
print
W2 = np.transpose(W2)
print("W2 = np.transpose(W2t):"), W2
print
print("First row of W2 = W2[0,:]")
print("W2[0,:]:"), W2[0,:]
print
print(W2[0])
print
print("W2[0].shape:"), W2[0].shape
print("W2[0] has shape {}").format(W2[0].shape)
print
h1_image = W2[28].reshape(28,28)
print
print("The weights into h1 have image ")
plt.imshow(h1_image)
print("plt.show():")
plt.show()
print
##w3 = net.weights[1]
##print w3
#print ""
##w3_op1 = w3[5]
##print "w3_op1.shape:", w3_op1.shape
##w3_op1 = w3_op1.reshape(1,30)
##op1 = np.dot(w3_op1,w2)
##op1 = op1.reshape(28,28)
##plt.imshow(op1)
#help(net.SGD)