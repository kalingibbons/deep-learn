# -*- coding: utf-8 -*-
"""
Created on Thu Aug 24 16:12:25 2017

@author: 
Stanford Course CS231n 
Convolutional Neural Networks for Visual Recognition
"""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from mpl_toolkits.mplot3d import Axes3D
np.random.seed(1234)
fig = plt.figure()
mpl.rcParams['legend.fontsize'] = 10
fig = plt.figure()
ax = fig.gca(projection='3d')
N = 100  # Number of data points
theta = np.linspace(-2 * np.pi, 2 * np.pi, N)+ 0.2*np.random.randn(N)
z = np.linspace(-2, 2, N)
r = 2
x = r * np.sin(theta)
y = r * np.cos(theta)
ax.plot(x, y, z, 'mo', label='parametric curve')
ax.legend()
plt.show()
Xt = np.c_[x,y,z]
X = np.transpose(Xt)
print
print("np.shape(X):", np.shape(X))

