# -*- coding: utf-8 -*-
"""
Created on Sun Oct 08 18:34:17 2017

@author: johnchiasson
"""
import numpy as np
import matplotlib.pyplot as plt

N = 100 # number of points per class
D = 2 # dimensionality
h = 4 # number of hidden neurons

X = np.zeros((300,2))
X[:, 0] = range(300)
X[:, 1] = range(300)
X = np.c_[X[:, 0], X[:, 1]]
print
print("X:"), X
print
print("X.shape:"), X.shape
print
# W = 0.01 * np.random.randn(D,h)
W = np.ones((D,h))
print
#print "W = 0.01 * np.random.randn(D,h)"
print("W = np.ones((D,h)):")
print
print("W:"), W
print
print("W.shape:"), W.shape
print
b = np.ones((1,h))
print("b = np.ones((1,h)):"), b
print
print("b.shape:"), b.shape
print
c = np.dot(X,W)
print("c = np.dot(X,W):"),c 
print
print("c.shape:"), c.shape
print
c2 = np.dot(X,W)+b
print
print("c2 = np.dot(X,W)+b")
print
print("c2:"), c2
print
print("c2.shape:"), c2.shape
