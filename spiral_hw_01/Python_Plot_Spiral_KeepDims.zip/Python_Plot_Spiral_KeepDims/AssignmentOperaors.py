# -*- coding: utf-8 -*-
"""
Created on Sun Oct 08 18:34:17 2017

@author: johnchiasson
"""
import numpy as np
import matplotlib.pyplot as plt

A=np.arange(12).reshape(2,6)
print("A:")
print(A)
print("")
print("A.shape:")
print(A.shape)
print("")
y = np.array([0,0,0,1,1,1])
print("y = np.array([0,0,0,1,1,1]):")
print(y)
print("")
print("range(6):")
print(range(6))
print("")
a = A[y,range(6)]
print("a = A[y,range(6)]:")
print(a)
print("")
print("A[y,range(6)] -= 1:")
A[y,range(6)] -= 1
print(A)