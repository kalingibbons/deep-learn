# -*- coding: utf-8 -*-
"""
Created on Thu Aug 24 16:12:25 2017

@author: Stanford Course CS231n 
Convolutional Neural Networks for Visual Recognition
"""
# initialize parameters randomly
h = 100 # size of hidden layer
W2t = 0.01 * np.random.randn(D,h)
b2t = np.zeros((1,h))
W3t = 0.01 * np.random.randn(h,K)
b3t = np.zeros((1,K))

# some hyperparameters
eta = 1e-0
lmbda = 1e-3 # regularization strength

# gradient descent loop
n = Xt.shape[0]
for i in range(10000):
  
  # evaluate class scores, [N x K]
  a2t = np.maximum(0, np.dot(Xt, W2t) + b2t) # note, ReLU activation
  z3t = np.dot(a2t, W3t) + b3t
  
  # compute the class probabilities
  exp_z3t = np.exp(z3t)
  a3t = exp_z3t / np.sum(exp_z3t, axis=1, keepdims=True) # [N x K]

  # compute the loss: average cross-entropy loss and regularization
  cost_y = -np.log(a3t[range(n),y])
  cost_y_avg  =  np.sum(cost_y)/n
  cost_W2W3 = 0.5*lmbda*np.sum(W2t*W2t) + 0.5*lmbda*np.sum(W3t*W3t)
  cost = cost_y_avg + cost_W2W3
  if i % 1000 == 0:
    print("iteration %d: loss %f" % (i, cost))
#  
  # compute the gradient on scores
  delta3t = a3t
  delta3t[range(n),y] -= 1
  delta3t /= n
#  
  # backpropate the gradient to the parameters
  # first backprop into parameters W3 and b3
  dW3t = np.dot(a2t.T, delta3t)
  db3t = np.sum(delta3t, axis=0, keepdims=True)
  # next backprop into hidden layer
  delta2t = np.dot(delta3t, W3t.T)
  # backprop the ReLU non-linearity
  delta2t[a2t <= 0] = 0
  # finally into W,b
  dW2t = np.dot(Xt.T, delta2t)
  db2t = np.sum(delta2t, axis=0, keepdims=True)
  
  # add regularization gradient contribution
  dW3t  += lmbda * W3t
  dW2t  += lmbda * W2t
  
  # perform a parameter update
  W2t += -eta * dW2t
  b2t += -eta * db2t
  W3t += -eta * dW3t
  b3t += -eta * db3t
  
  # evaluate training set accuracy
a2t = np.maximum(0, np.dot(Xt, W2t) + b2t)
a3t = np.dot(a2t, W3t) + b3t
predicted_class = np.argmax(a3t, axis=1)
print('training accuracy: %.2f' % (np.mean(predicted_class == y)))
#
# plot the resulting classifier
g = 0.02
x_min, x_max = Xt[:, 0].min() - 1, Xt[:, 0].max() + 1
y_min, y_max = Xt[:, 1].min() - 1, Xt[:, 1].max() + 1
xx, yy = np.meshgrid(np.arange(x_min, x_max, g),
                     np.arange(y_min, y_max, g))     
print
print("xx.shape:", xx.shape)
print
print("yy.shape:", yy.shape)
print
#Zt = np.dot(np.maximum(0, np.dot(np.c_[xx.ravel(), yy.ravel()], W2t) + b2t), W3t) + b3t
Xt_grid = np.c_[xx.ravel(), yy.ravel()]
a2t = np.maximum(0, np.dot(Xt_grid, W2t) + b2t)
Zt = np.dot(a2t, W3t) + b3t       
Zt = np.argmax(Zt, axis=1)
Zt = Zt.reshape(xx.shape)
fig = plt.figure()
plt.contourf(xx, yy, Zt, cmap=plt.cm.Spectral, alpha=0.8)
plt.scatter(Xt[:, 0], Xt[:, 1], c=y, s=40, cmap=plt.cm.Spectral)
plt.xlim(xx.min(), xx.max())
plt.ylim(yy.min(), yy.max())
fig.savefig('spiral_net.png')


