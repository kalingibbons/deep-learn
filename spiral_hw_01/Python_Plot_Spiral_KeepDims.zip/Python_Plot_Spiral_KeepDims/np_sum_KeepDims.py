# -*- coding: utf-8 -*-
"""
Created on Sun Oct 08 18:34:17 2017

@author: johnchiasson
"""
import numpy as np
import matplotlib.pyplot as plt

A=np.arange(12).reshape(3,4)
print("A:")
print(A)
print("A.shape:"), A.shape
print
A_col = np.sum(A,axis=0)
print("A_col = np.sum(A,axis=0):")
print(A_col)
print("A_col.shape:"), A_col.shape
print
A_row = np.sum(A,axis=1)
print("A_row = np.sum(A,axis=1):")
print(A_row)
print("A_row.shape:"), A_row.shape
print
print
A_col2 = np.sum(A,axis=0, keepdims = True)
print("A_col2 = np.sum(A,axis=0, keepdims = True):")
print(A_col2)
print("A_col2.shape:"), A_col2.shape
print
A_row2 = np.sum(A,axis=1, keepdims = True)
print("A_row2 = np.sum(A,axis=1, keepdims = True):")
print(A_row2)
print("A_row.shape:"), A_row2.shape
print
print("A")
print(A)
print
A_shift_row=np.roll(A, 1, axis=0)
print
print("np.roll(A, 1, axis=0):")
print
print(A_shift_row)
print 
print
print("A")
print(A)
print
A_shift_col=np.roll(A, 1, axis=1)
print("np.roll(A, 1, axis=1):")
print 
print(A_shift_col)
print


