# -*- coding: utf-8 -*-
"""
Created on Fri Sep 15 16:10:58 2017

@author: johnchiasson
"""
import numpy as np
import matplotlib.pyplot as plt
print("len(net.weights):"), len(net.weights)
print
print("net.weights[0].shape:"), net.weights[0].shape
print
w2 = net.weights[0]
print("w2 = net.weights[0]:")
print(net.weights[0])
print
print("First row of w2[0] = net.weights[0][0]:")
print
print(w2[0])
print
print("w2[0].shape:"), w2[0].shape
print("w2[0] has shape {}").format(w2[0].shape)
print 
h1_image = w2[21].reshape(28,28)
print
print("The weights into h1 have image ")
#h1_image = 1*np.ones([28,28])
plt.imshow(h1_image,cmap='BuPu', origin='higher')
plt.colorbar()
#plt.xticks(())
#plt.yticks(())
print("plt.show():")
plt.show()
print
#w3 = net.weights[1]
#print w3
print
#w3_op1 = w3[5]
#print "w3_op1.shape:", w3_op1.shape
#w3_op1 = w3_op1.reshape(1,30)
#op1 = np.dot(w3_op1,w2)
#op1 = op1.reshape(28,28)
#plt.imshow(op1)
#help(net.SGD)
